/**
 * @priya singh
 * Java Program to perform sorting operations with Comparator interface.
 *  
 */

package com.Collection;
                                 //importing Collections
import java.util.ArrayList;
import java.util.Collections;

import static java.lang.System.*;

public class ClassRoom {

	public static void main(String[] args) {
		student s1 =new student(5,"vishu", 19, 77);
		student s2 =new student(11,"Abhi", 21, 88);
		student s3 =new student(21,"Tanishka", 18, 70);
		student s4 =new student(10, "Manpreet", 20, 90);
		student s5 =new student(18,"Aku",19,89);
		//creating Array List
		ArrayList<student> al =new ArrayList<student>();
		al.add(s1);
		al.add(s2);
		al.add(s3);
		al.add(s4);
		al.add(s5);
		
		
		out.println("\t\t***Student List Based on Id*** ");
		//sorting ArrayList element on the basic of studentId 
		Collections.sort(al,new IdComparator()); 
		for(student s:al) {
			out.println("Ids:-" +s.studentId +"Name:-" +s.studentName + "Ae:-" +s.studentAge + "Marks:-"+s.studentMarks);
		}
		//Sorting ArrayList elements on the basis of  Age.
			out.println("\t\t***student List Based on Age***");
			Collections.sort(al,new AgeComparator());
			for(student s:al) {
				out.println("Age: "+s.studentAge+"Name:"+s.studentName+"Id:"+s.studentId+"Marks:"+s.studentMarks);
				
			}
			//Sorting ArrayList elements on the basis of  marks.
			out.println("\t\t***student List Based on Marks***");
			Collections.sort(al,new MarksComparator());
			for(student s:al) {
				out.println("Marks:"+s.studentMarks+"Name:"  +s.studentName+"Id:"+s.studentId+"Age:"+s.studentAge);
				
				
			}
		
		

	}

}
