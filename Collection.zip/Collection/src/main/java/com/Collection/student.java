package com.Collection;

public class student {
	int studentId;
	String studentName;
	int studentAge;
	int studentMarks;
	public student(int studentId, String studentName, int studentAge, int studentMarks) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentAge = studentAge;
		this.studentMarks = studentMarks;
	}
	
	
	

}
