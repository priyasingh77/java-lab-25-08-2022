package com.Collection;

import java.util.Comparator;

public class IdComparator implements Comparator <student>{

	@Override
	public int compare(student s1, student s2) {
		if (s1.studentMarks==s2.studentMarks) 
			return 0;
			if (s1.studentId>s2.studentId)
				return 1;
			else
				return -1;
		
	}
	

}
